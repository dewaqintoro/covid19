import React, { useEffect, useState } from "react";
import Link from 'next/link'
import { connect } from 'react-redux';
import { useRouter } from 'next/router'
const Bawah = ({ dispatch, isSignedIn, userId }) => {
  const [auth, setAuth] = useState(null);

  useEffect(() => {
    const params = {
      clientId:
        "665583303856-dee0npijq291ee7iq30og902mkg1bc7a.apps.googleusercontent.com",
      scope: "email",
    };

    window.gapi.load("client:auth2", () => {
      window.gapi.client.init(params).then(() => {
        setAuth(window.gapi.auth2.getAuthInstance());
        onAuthChange(window.gapi.auth2.getAuthInstance().isSignedIn.get());
        window.gapi.auth2.getAuthInstance().isSignedIn.listen(onAuthChange);
      });
    });
  }, []);

  const onAuthChange = (isSignedIn) => {
    if (isSignedIn) {
      dispatch(
        AuthorizationAction.signIn(
          window.gapi.auth2.getAuthInstance().currentUser.get().getId()
        )
      );
    } else {
      dispatch(AuthorizationAction.signOut());
      console.log("berhasil logout v2");
    }
  };


  const router = useRouter()

  const onSignOutClick = () => {
    auth.signOut();
    console.log("berhasil logout v1");
    router.push('/')
    
  };

  return (
    <div className="bawahContainer">
      <Link href="/setting">
        <div className="bawah" id="setting">
            <img className="imgBawah" src="https://res.cloudinary.com/dewaqintoro/image/upload/v1596626011/icon/mdi_settings_hvxc7l.png"/>
        </div>
      </Link>

      <Link href="/">
        <div className="bawah" id="logout">
        <button onClick={onSignOutClick}>Signout</button>
            <img className="imgBawah" src="https://res.cloudinary.com/dewaqintoro/image/upload/v1596626011/icon/mdi_power_settings_new_z0g0h1.png"/>
        </div>
      </Link>
    </div>
  )
}

const mapStateToProps = (state) => {
  return { isSignedIn: state.auth.isSignedIn, userId: state.auth.userId };
};

export default connect(mapStateToProps) (Bawah)
