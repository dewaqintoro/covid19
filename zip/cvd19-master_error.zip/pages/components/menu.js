import React from 'react'
import Link from 'next/link'
import { Layout, Menu } from 'antd';
import { EnvironmentOutlined,DashboardOutlined } from '@ant-design/icons';


const MenuDew = () => {
  return (
    <>
    <Menu mode="inline" defaultSelectedKeys="1">
            <Menu.Item key="1" icon={<DashboardOutlined />}>
              <Link href="/admin">
                Dashboard 
              </Link>
            </Menu.Item>
            <Menu.Item key="2" icon={<EnvironmentOutlined />}>
              <Link href="/persebaran">
                Persebaran
              </Link>
            </Menu.Item>
            {/* <Menu.Item key="3" icon={<UploadOutlined />}>
              nav 3 
            </Menu.Item>
            <Menu.Item key="4" icon={<UserOutlined />}>
              nav 4
            </Menu.Item> */}
            
        </Menu>
    </>
  )
}

export default MenuDew
