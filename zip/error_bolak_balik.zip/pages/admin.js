import React, { useEffect, useState } from "react";

import { Layout, Menu } from 'antd';
import { UploadOutlined, UserOutlined, VideoCameraOutlined } from '@ant-design/icons';
import Link from 'next/link'
const { Header, Content, Footer, Sider } = Layout;
import SideCompDew from './components/SideCompDew';
 import Kasus from './kasus'
import { connect } from 'react-redux';
import { useRouter } from 'next/router'

const AdminPage = () => {
  const router = useRouter()

  // const [auth, setAuth] = useState(null);


  const renderAuthButton = () => {
    if (isSignedIn === null) {
      return null; 
    } else if (isSignedIn) {
      console.log("sudah login")
      // router.push('/admin')
    } else {
      console.log("Belum login")
      router.push('/')
    }
  };
 

  return (
    <div>
      {/* {renderAuthButton()} */}
    <Layout> 
      <SideCompDew aktif="1"/>
      <Layout>
        <Content style={{ margin: '24px 16px 0' }}>
          <div className="site-layout-background" style={{ padding: 24, minHeight: 760 }}>
          <div>
       </div>
            <Kasus/>
          </div>
        </Content>
      </Layout>
    </Layout>
  </div>
  )
}

// const mapStateToProps = (state) => {
//   return { isSignedIn: state.auth.isSignedIn, userId: state.auth.userId };
// };
export default connect() (AdminPage)