import React, { useEffect, useState } from "react";

import { Layout, Menu } from 'antd';
import { EnvironmentOutlined,DashboardOutlined } from '@ant-design/icons';
import Link from 'next/link'
const { Header, Content, Footer, Sider } = Layout;

import { connect } from 'react-redux';
import { useRouter } from 'next/router'

const SideCompDew = (props,{ dispatch, isSignedIn, userId }) => {
  const router = useRouter()
  const [auth, setAuth] = useState(null);

  useEffect(() => {
    const params = {
      clientId:
        "665583303856-dee0npijq291ee7iq30og902mkg1bc7a.apps.googleusercontent.com",
      scope: "email",
    };

    window.gapi.load("client:auth2", () => {
      window.gapi.client.init(params).then(() => {
        setAuth(window.gapi.auth2.getAuthInstance());
        onAuthChange(window.gapi.auth2.getAuthInstance().isSignedIn.get());
        window.gapi.auth2.getAuthInstance().isSignedIn.listen(onAuthChange);
      });
    });
  }, []);

  const onAuthChange = (isSignedIn) => {
    if (isSignedIn) {
      dispatch(
        AuthorizationAction.signIn(
          window.gapi.auth2.getAuthInstance().currentUser.get().getId()
        )
      );
    } else {
      dispatch(AuthorizationAction.signOut());
      console.log("berhasil logout v2");
    }
  };



  const  onSignOutClick = async () => {
    auth.signOut();
    // await router.push('/')
    console.log("berhasil logout v1");
    
  };
  return (
    <>
              <Sider
          breakpoint="lg" 
          collapsedWidth="0"
          onBreakpoint={broken => {
            console.log(broken);
          }}
          onCollapse={(collapsed, type) => {
          console.log(collapsed, type);
          }}
        >

          
          {/* <div className="logo" /> */}
          <div className="center profil">
            <div className="imgProfil">
                <img id="imgProfil" src="https://res.cloudinary.com/dewaqintoro/image/upload/v1596626011/icon/bx_bxs-user-circle_kfbclt.png"/>
            </div>
            <p id="username" style={{textalign: "center"}}>Dewa Qintoro</p>
        <p id="id" style={{textalign: "center"}}>{props.userId}</p>
          </div>
          <Menu mode="inline" defaultSelectedKeys={props.aktif}>
            <Menu.Item key="1" icon={<DashboardOutlined />}>
              <Link href="/admin">
                Dashboard 
              </Link>
            </Menu.Item>
            <Menu.Item key="2" icon={<EnvironmentOutlined />}>
              <Link href="/persebaran">
                Persebaran
              </Link>
            </Menu.Item>
            {/* <Menu.Item key="3" icon={<UploadOutlined />}>
              nav 3 
            </Menu.Item>
            <Menu.Item key="4" icon={<UserOutlined />}>
              nav 4
            </Menu.Item> */}
            <div className="bawahContainer">
            
            {/* <Link href="/setting">
              <div className="bawah" id="setting">
                  <img className="imgBawah" src="https://res.cloudinary.com/dewaqintoro/image/upload/v1596626011/icon/mdi_settings_hvxc7l.png"/>
              </div>
            </Link> */}
 
            <Link href="/">
              <div className="bawah" id="logout">
              {/* <button className="btnLogout" onClick={onSignOutClick}> */}
              <button className="btnLogout" onClick={() => onSignOutClick,router.push('/')}>
                  <img className="imgBawah" src="https://res.cloudinary.com/dewaqintoro/image/upload/v1596626011/icon/mdi_power_settings_new_z0g0h1.png"/>
              </button>
              </div>
            </Link>
            </div>
          </Menu>
        </Sider>
    </>
  ) 
} 
 
const mapStateToProps = (state) => {
  return { isSignedIn: state.auth.isSignedIn, userId: state.auth.userId };
};

export default connect(mapStateToProps) (SideCompDew)


