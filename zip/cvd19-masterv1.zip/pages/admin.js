import React, { Component } from 'react'

import { Layout, Menu } from 'antd';
import { UploadOutlined, UserOutlined, VideoCameraOutlined } from '@ant-design/icons';
import Link from 'next/link'
const { Header, Content, Footer, Sider } = Layout;
import SideCompDew from './components/SideCompDew';
 import Kasus from './kasus'
import { connect } from 'react-redux';

class AdminPage extends Component {

  render({ dispatch, isSignedIn, userId }) {
    const [auth, setAuth] = useState(null);
    const onSignOutClick = () => {
      auth.signOut();
    };
    return (
    <div>
      <Layout> 
        <SideCompDew aktif="1"/>
        <Layout>
          <Content style={{ margin: '24px 16px 0' }}>
            <div className="site-layout-background" style={{ padding: 24, minHeight: 760 }}>
            <div>
           <span>{userId}</span>
           <button onClick={onSignOutClick}>Signout</button>
         </div>
              <Kasus/>
              {/* <h1>Admin Page</h1>
              <div className="adminPage">
                <p></p>
              </div> */}
            </div>
          </Content>
        </Layout>
      </Layout>
    </div>
    )
  }
}
const mapStateToProps = (state) => {
  return { isSignedIn: state.auth.isSignedIn, userId: state.auth.userId };
};
export default connect(mapStateToProps) (AdminPage)