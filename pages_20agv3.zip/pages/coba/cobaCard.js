import React from 'react'

const CobaCard = () => {
  return (
    <div>
      
    </div>
  )
}

export default CobaCard