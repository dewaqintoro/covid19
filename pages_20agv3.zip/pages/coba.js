import React from 'react'

const Coba = () => {
  return (
    <div>
      coba
    </div>
  )
}

export default Coba
